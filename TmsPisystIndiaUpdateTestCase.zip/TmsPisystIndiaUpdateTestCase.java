package TestCase;

import java.io.InputStream;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import PO.TmsPisystIndiaUpdatePO;
import Utility.BrowserManager;

public class TmsPisystIndiaUpdateTestCase
{
	WebDriver driver;			//to initialize the Browser
	JSONObject TmsPisystIndiaUpdateData;	//to create a json object to read data
	@BeforeClass
	public void beforeClass() throws Exception
	{
		InputStream datais=null;
		try
		{
			String dataFileName="data/TmsPisystIndiaUpdateData.json";
			datais=getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(datais);
			TmsPisystIndiaUpdateData =new JSONObject(tokener);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(datais != null)
			{
				datais.close();	
			}
		}
		
	}
	@BeforeMethod //precondition
	@Parameters({"browser","url"})
	public void setup(String browser,String url) //parameter method
	{
		driver=BrowserManager.getDriver(browser);
		driver.get(url);
		driver.manage().window().maximize();
	}
		
		
	@Test
	public void Valid_Data() throws InterruptedException
	{
			String Procurement_email=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("email");
			String Procurement_password=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("password");
			String Component_name=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("name");
			String Component_image=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("image");
			String Component_code=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("code");
			String Component_material=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("material");
			String Component_description=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("description");
			TmsPisystIndiaUpdatePO obj=PageFactory.initElements(driver, TmsPisystIndiaUpdatePO.class);
			obj.All_Valid_Data(Procurement_email,Procurement_password,Component_name,Component_image,Component_code,Component_material,Component_description);
		
	}
	@Test
	public void Inalid_Data() throws InterruptedException
	{
			String Procurement_email=TmsPisystIndiaUpdateData.getJSONObject("All_Invalid").getString("email");
			String Procurement_password=TmsPisystIndiaUpdateData.getJSONObject("All_Invalid").getString("password");
			String Component_name=TmsPisystIndiaUpdateData.getJSONObject("All_Invalid").getString("name");
			String Component_image=TmsPisystIndiaUpdateData.getJSONObject("All_Invalid").getString("image");
			String Component_code=TmsPisystIndiaUpdateData.getJSONObject("All_Invalid").getString("code");
			String Component_material=TmsPisystIndiaUpdateData.getJSONObject("All_Invalid").getString("material");
			String Component_description=TmsPisystIndiaUpdateData.getJSONObject("All_Invalid").getString("description");
			TmsPisystIndiaUpdatePO obj=PageFactory.initElements(driver, TmsPisystIndiaUpdatePO.class);
			obj.All_Invalid_Data(Procurement_email,Procurement_password,Component_name,Component_image,Component_code,Component_material,Component_description);
	} 
	@Test
	public void Blank_Data() throws InterruptedException
	{
			String Procurement_email=TmsPisystIndiaUpdateData.getJSONObject("All_Blank").getString("email");
			String Procurement_password=TmsPisystIndiaUpdateData.getJSONObject("All_Blank").getString("password");
			String Component_name=TmsPisystIndiaUpdateData.getJSONObject("All_Blank").getString("name");
			String Component_image=TmsPisystIndiaUpdateData.getJSONObject("All_Blank").getString("image");
			String Component_code=TmsPisystIndiaUpdateData.getJSONObject("All_Blank").getString("code");
			String Component_material=TmsPisystIndiaUpdateData.getJSONObject("All_Blank").getString("material");
			String Component_description=TmsPisystIndiaUpdateData.getJSONObject("All_Blank").getString("description");
			TmsPisystIndiaUpdatePO obj=PageFactory.initElements(driver, TmsPisystIndiaUpdatePO.class);
			obj.All_Blank_Data(Procurement_email,Procurement_password,Component_name,Component_image,Component_code,Component_material,Component_description);
	} 
	
	@Test
	public void All_Valid_AND_ComponentName_Invalid() throws InterruptedException
	{
			String Procurement_email=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("email");
			String Procurement_password=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("password");
			String Component_name=TmsPisystIndiaUpdateData.getJSONObject("All_Invalid").getString("name");
			String Component_image=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("image");
			String Component_code=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("code");
			String Component_material=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("material");
			String Component_description=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("description");
			TmsPisystIndiaUpdatePO obj=PageFactory.initElements(driver, TmsPisystIndiaUpdatePO.class);
			obj.All_Valid_AND_ComponentName_Invalid(Procurement_email,Procurement_password,Component_name,Component_image,Component_code,Component_material,Component_description);
	} 
	@Test
	public void All_Valid_AND_ComponentImage_Invalid() throws InterruptedException
	{
			String Procurement_email=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("email");
			String Procurement_password=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("password");
			String Component_name=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("name");
			String Component_image=TmsPisystIndiaUpdateData.getJSONObject("All_Invalid").getString("image");
			String Component_code=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("code");
			String Component_material=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("material");
			String Component_description=TmsPisystIndiaUpdateData.getJSONObject("All_Valid").getString("description");
			TmsPisystIndiaUpdatePO obj=PageFactory.initElements(driver, TmsPisystIndiaUpdatePO.class);
			obj.All_Valid_AND_ComponentImage_Invalid(Procurement_email,Procurement_password,Component_name,Component_image,Component_code,Component_material,Component_description);
	} 
}
