package UI;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TmsPisystIndiaUI 
{
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\browerDriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://tms.pisystindia.com/procurement/component/addview");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='procurement_email']")).sendKeys("salesman81@gmail.com");
		//Thread.sleep(3000);
		driver.findElement(By.id("procurement_password")).sendKeys("123456");
		//Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		Thread.sleep(3000);
		//driver.get("https://tms.pisystindia.com/procurement/component");
		driver.findElement(By.xpath("//a[@href=\"https://tms.pisystindia.com/procurement/component\"]")).click();
		Thread.sleep(3000);
		//driver.get("https://tms.pisystindia.com/procurement/component/addview");
		driver.findElement(By.xpath("//a[@href=\"https://tms.pisystindia.com/procurement/component/addview\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='component_name']")).sendKeys("xyz");
		//Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='component_image']")).sendKeys("C:\\Users\\SONU\\Desktop\\flower.jpg");
		//Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='component_code']")).sendKeys("aaaaa");
		//Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='component_material']")).sendKeys("pqr");
		//Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='component_description']")).sendKeys("mno");
		Thread.sleep(3000);
		//driver.findElement(By.xpath("//button[@onclick='return add()']")).click();
	}
	
}
