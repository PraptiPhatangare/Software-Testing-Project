package PO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;

public class TmsPisystIndiaUpdatePO
{
	WebDriver driver;
	public void TmsPisystIndiaUpdatePO(WebDriver driver)
	{
		this.driver=driver;
	}
	@FindBy(how=How.XPATH,using="//input[@id='procurement_email']")
		WebElement txt_procurement_email;
	@FindBy(how=How.XPATH,using="//input[@id='procurement_password']")
		WebElement txt_procurement_password;
	@FindBy(how=How.XPATH,using="//button[@type='submit']")
		WebElement txt_submit;
	
	
	/*@FindBy(how=How.XPATH,using="//a[@href='https://tms.pisystindia.com/procurement/tools']")
		WebElement txt_tools;
	@FindBy(how=How.XPATH,using="//h1[text()='TOOLS']")
		WebElement txt_title;
	*/
	
	@FindBy(how=How.XPATH,using="/html/body/div[1]/div/div[1]/ul/li[4]/a")
	WebElement btn_component;
	@FindBy(how=How.XPATH,using="//a[@href='https://tms.pisystindia.com/procurement/component/addview']")
	WebElement btn_addview;

	@FindBy(how=How.XPATH,using="//input[@id='component_name']")
	WebElement txt_component_name;
	@FindBy(how=How.XPATH,using="//input[@id='component_image']")
	WebElement txt_component_image;
	@FindBy(how=How.XPATH,using="//input[@id='component_code']")
	WebElement txt_component_code;
	@FindBy(how=How.XPATH,using="//input[@id='component_material']")
	WebElement txt_component_material;
	@FindBy(how=How.XPATH,using="//input[@id='component_description']")
	WebElement txt_component_description;
	@FindBy(how=How.XPATH,using="//button[@onclick='return add()']")
	WebElement txt_add;
	
	public void procurement_email(String args)
	{
		txt_procurement_email.clear();
		txt_procurement_email.sendKeys(args);
	}
	public void procurement_password(String args)
	{
		txt_procurement_password.clear();
		txt_procurement_password.sendKeys(args);
	}
	public void submit()
	{
		//txt_submit.clear();
		txt_submit.click();
	}

	
	public void component()
	{
		//txt_component.clear();
		btn_component.click();
	}
	public void addview()
	{
		//txt_addview.clear();
		btn_addview.click();
	}
	
	public void component_name(String args)
	{
		txt_component_name.clear();
		txt_component_name.sendKeys(args);
	}
	public void component_image(String args)
	{
		txt_component_image.clear();
		txt_component_image.sendKeys(args);
	}
	public void component_code(String args)
	{
		txt_component_code.clear();
		txt_component_code.sendKeys(args);
	}
	public void component_material(String args)
	{
		txt_component_material.clear();
		txt_component_material.sendKeys(args);
	}
	public void component_description(String args)
	{
		txt_component_description.clear();
		txt_component_description.sendKeys(args);
	}
	public void add()
	{
		//txt_add.clear();
		txt_add.click();
	}
	
	public String verifyTitle()
	{
		String MyTitle=driver.getTitle();
		System.out.println("the title are:"+MyTitle);
		return MyTitle;
	}
	
	public void All_Valid_Data(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		//Thread.sleep(1000);
		component_image(Component_image);
		//Thread.sleep(1000);
		component_code(Component_code);
		//Thread.sleep(1000);
		component_material(Component_material);
		//Thread.sleep(1000);
		component_description(Component_description);
		//Thread.sleep(1000);
		add();	
		//Assert.assertEquals(true,txt_title.isDisplayed());
	}
	public void All_Invalid_Data(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Blank_Data(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentName_Invalid(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentImage_Invalid(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentCode_Invalid(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentMaterial_Invalid(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentDescription_Invalid(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentName_Blank(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentImage_Blank(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentCode_Blank(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentMaterial_Blank(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	public void All_Valid_AND_ComponentDescription_Blank(String Procurement_email,String Procurement_password, String Component_name,String Component_image,String Component_code, String Component_material, String Component_description ) throws InterruptedException
	{
		procurement_email(Procurement_email);
		Thread.sleep(1000);
		procurement_password(Procurement_password);
		Thread.sleep(1000);
		submit();
		component();
		addview();
		component_name(Component_name);
		Thread.sleep(1000);
		component_image(Component_image);
		Thread.sleep(1000);
		component_code(Component_code);
		Thread.sleep(1000);
		component_material(Component_material);
		Thread.sleep(1000);
		component_description(Component_description);
		Thread.sleep(1000);
		add();	
		//Assert.assertEquals(verifyTitle(),"Add Component");
	}
	
	
}
