 package PO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.relevantcodes.extentreports.LogStatus;

import XLogistReport.ExtentReport;

public class TmsPisystIndiaLoginPO 
{
	WebDriver driver;
	public void TmsPisystIndiaLoginPO(WebDriver driver)
	{
		this.driver=driver;
	}
	@FindBy(how=How.XPATH,using="//input[@id='procurement_email']")
		WebElement txt_procurement_email;
	@FindBy(how=How.XPATH,using="//input[@id='procurement_password']")
		WebElement txt_procurement_password;
	@FindBy(how=How.XPATH,using="//button[@type='submit']")
		WebElement txt_submit;
	
	public void procurement_email(String args)
	{
		txt_procurement_email.clear();
		txt_procurement_email.sendKeys(args);
		ExtentReport.test.log(LogStatus.INFO,"enter email no.", args);
	}
	public void procurement_password(String args)
	{
		txt_procurement_password.clear();
		txt_procurement_password.sendKeys(args);
		ExtentReport.test.log(LogStatus.INFO,"enter password no.", args);
	}
	public void submit()
	{
		txt_submit.click();
		ExtentReport.test.log(LogStatus.INFO,"click submit", "submit");
	}
	public void Valid_Email_AND_Valid_Password(String Procurement_email,String Procurement_password) throws InterruptedException
	{
		try 
		{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void Valid_Email_AND_Invalid_Password(String Procurement_email,String Procurement_password) throws InterruptedException
	{
		try
		{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void  Invalid_Email_AND_Valid_Password(String Procurement_email,String Procurement_password) throws InterruptedException
	{
		try
		{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void Invalid_Email_AND_Invalid_Password(String Procurement_email,String Procurement_password) throws InterruptedException
	{
		try
		{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void  Blank_Email_AND_Blank_Password(String Procurement_email,String Procurement_password) throws InterruptedException
	{
		try
		{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void Blank_Email_AND_Valid_Password(String Procurement_email,String Procurement_password) throws InterruptedException
	{
		try
		{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void Valid_Email_AND_Blank_Password(String Procurement_email,String Procurement_password) throws InterruptedException
	{
		try
		{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void  Blank_Email_AND_Invalid_Password(String Procurement_email,String Procurement_password) throws InterruptedException
	{
		try
		{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void  Invalid_Email_AND_Blank_Password(String Procurement_email,String Procurement_password) throws InterruptedException
	{
		try
		{
		procurement_email(Procurement_email);
		//Thread.sleep(1000);
		procurement_password(Procurement_password);
		//Thread.sleep(1000);
		submit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
