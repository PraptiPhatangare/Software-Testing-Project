package TestCase;

import java.io.InputStream;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import PO.TmsPisystIndiaLoginPO;
import Utility.BrowserManager;
import XLogistReport.ExtentReport;

public class TmsPisystIndiaLoginTestCase 
{
	WebDriver driver;			//to initialize the Browser
	JSONObject TmsPisystIndiaLoginData;	//to create a json object to read data
	@BeforeClass
	public void beforeClass() throws Exception
	{
		ExtentReport.startreport();
		InputStream datais=null;
		try
		{
			String dataFileName="data/TmsPisystIndiaLoginData.json";
			datais=getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(datais);
			TmsPisystIndiaLoginData =new JSONObject(tokener);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(datais != null)
			{
				datais.close();	
			}
		}
		
	}
	@BeforeMethod //precondition
	@Parameters({"browser","url"})
	public void setup(String browser,String url) //parameter method
	{
		driver=BrowserManager.getDriver(browser);
		driver.get(url);
		driver.manage().window().maximize();
	}
		
		
	@Test
	public void TMS_Valid_Data() throws InterruptedException
	{
			String Procurement_email=TmsPisystIndiaLoginData.getJSONObject("All_Valid").getString("email");
			String Procurement_password=TmsPisystIndiaLoginData.getJSONObject("All_Valid").getString("password");
			
			ExtentReport.test=ExtentReport.extent.startTest("valid");
			
			TmsPisystIndiaLoginPO obj=PageFactory.initElements(driver, TmsPisystIndiaLoginPO.class);
			obj.Valid_Email_AND_Valid_Password(Procurement_email,Procurement_password);
			//driver.close();
	}
	/*@Test
	public void TMS_Invalid_Data() throws InterruptedException
	{
			String procurement_email=TmsPisystIndiaLoginData.getJSONObject("All_Invalid").getString("email");
			String procurement_password=TmsPisystIndiaLoginData.getJSONObject("All_Invalid").getString("password");
			
			ExtentReport.test=ExtentReport.extent.startTest("Invalid");
			
			TmsPisystIndiaLoginPO obj=PageFactory.initElements(driver, TmsPisystIndiaLoginPO.class);
			obj.Invalid_Email_AND_Invalid_Password(procurement_email,procurement_password);
			driver.close();
	}
	@Test
	public void TMS_Valid_AND_Invalid_Data() throws InterruptedException
	{
			String procurement_email=TmsPisystIndiaLoginData.getJSONObject("All_Valid").getString("email");
			String procurement_password=TmsPisystIndiaLoginData.getJSONObject("All_Invalid").getString("password");
			
			ExtentReport.test=ExtentReport.extent.startTest("valid & invalid");
			
			TmsPisystIndiaLoginPO obj=PageFactory.initElements(driver, TmsPisystIndiaLoginPO.class);
			obj.Valid_Email_AND_Invalid_Password(procurement_email,procurement_password);
			driver.close();
	}
	@Test
	public void TMS_Invalid_Email_AND_Valid_Password() throws InterruptedException
	{
			String procurement_email=TmsPisystIndiaLoginData.getJSONObject("All_Invalid").getString("email");
			String procurement_password=TmsPisystIndiaLoginData.getJSONObject("All_Valid").getString("password");
			
			ExtentReport.test=ExtentReport.extent.startTest("invalid & valid");
			
			TmsPisystIndiaLoginPO obj=PageFactory.initElements(driver, TmsPisystIndiaLoginPO.class);
			obj.Invalid_Email_AND_Valid_Password(procurement_email,procurement_password);
			driver.close();
	}
	@Test
	public void TMS_Blank_Email_AND_Blank_Password() throws InterruptedException
	{
			String procurement_email=TmsPisystIndiaLoginData.getJSONObject("All_Blank").getString("email");
			String procurement_password=TmsPisystIndiaLoginData.getJSONObject("All_Blank").getString("password");
			
			ExtentReport.test=ExtentReport.extent.startTest("Blank");
			
			TmsPisystIndiaLoginPO obj=PageFactory.initElements(driver, TmsPisystIndiaLoginPO.class);
			obj.Blank_Email_AND_Blank_Password(procurement_email,procurement_password);
			driver.close();
	}
	@Test
	public void TMS_Blank_Email_AND_Valid_Password() throws InterruptedException
	{
			String procurement_email=TmsPisystIndiaLoginData.getJSONObject("All_Blank").getString("email");
			String procurement_password=TmsPisystIndiaLoginData.getJSONObject("All_Valid").getString("password");
			
			ExtentReport.test=ExtentReport.extent.startTest("Blank & valid");
			
			TmsPisystIndiaLoginPO obj=PageFactory.initElements(driver, TmsPisystIndiaLoginPO.class);
			obj.Blank_Email_AND_Valid_Password(procurement_email,procurement_password);
			driver.close();
	}
	@Test
	public void TMS_Valid_Email_AND_Blank_Password() throws InterruptedException
	{
			String procurement_email=TmsPisystIndiaLoginData.getJSONObject("All_Valid").getString("email");
			String procurement_password=TmsPisystIndiaLoginData.getJSONObject("All_Blank").getString("password");
			
			ExtentReport.test=ExtentReport.extent.startTest("valid & Blank");
			
			TmsPisystIndiaLoginPO obj=PageFactory.initElements(driver, TmsPisystIndiaLoginPO.class);
			obj.Valid_Email_AND_Blank_Password(procurement_email,procurement_password);
			driver.close();
	}  
	@Test
	public void TMS_Blank_Email_AND_Invalid_Password() throws InterruptedException
	{
			String procurement_email=TmsPisystIndiaLoginData.getJSONObject("All_Blank").getString("email");
			String procurement_password=TmsPisystIndiaLoginData.getJSONObject("All_Invalid").getString("password");
			
			ExtentReport.test=ExtentReport.extent.startTest("Blank & invalid");
			
			TmsPisystIndiaLoginPO obj=PageFactory.initElements(driver, TmsPisystIndiaLoginPO.class);
			obj.Blank_Email_AND_Invalid_Password(procurement_email,procurement_password);
			driver.close();
	}  
	@Test
	public void TMS_Invalid_Email_AND_Blank_Password() throws InterruptedException
	{
			String procurement_email=TmsPisystIndiaLoginData.getJSONObject("All_Invalid").getString("email");
			String procurement_password=TmsPisystIndiaLoginData.getJSONObject("All_Blank").getString("password");
			
			ExtentReport.test=ExtentReport.extent.startTest("invalid & Blank");
			
			TmsPisystIndiaLoginPO obj=PageFactory.initElements(driver, TmsPisystIndiaLoginPO.class);
			obj.Invalid_Email_AND_Blank_Password(procurement_email,procurement_password);
			driver.close();
	} */ 	
}
